#include "includes.h"
using namespace std;

void saveList(vector<string> savesArray) {
  ofstream myfile;
  myfile.open ("games.txt", ios::out);
 

  
  for(int i = 0; i < savesArray.size(); i++) {      // looping until i = size of vector
    myfile << savesArray[i] << "\n";                // prints favorite games vector
  }
   myfile.close();
}