#include "includes.h"
using namespace std;

vector<string> loadList() {

  ifstream nameFile ("games.txt");    
  string line;                          
  vector<string> names;
  if(nameFile.is_open()) {              
    while(getline(nameFile, line)) {     
      // cout << line << "\n";                
      names.push_back(line);  // Update to store the content in the loadsArray vector
    }
  } else {
    cout << "could not read from nameFile.\n";
  }
  // for(int i = 0; i < names.size(); i++) {      
  //   cout << names[i] << "\n";                
  // }
  
  nameFile.close();
  return names; 
}